package com.example.khaphan.mywallet;

/**
 * Created by kha.phan on 6/17/2016.
 */
public class WalletManagerAdapter {
}
